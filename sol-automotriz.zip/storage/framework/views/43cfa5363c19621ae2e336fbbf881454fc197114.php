



<?php $__env->startSection('title', 'JSOL Automotriz'); ?>





<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\sol-automotriz\resources\views/layouts/app.blade.php ENDPATH**/ ?>