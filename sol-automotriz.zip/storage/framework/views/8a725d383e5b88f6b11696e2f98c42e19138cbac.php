

<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header">
      <h3 class="page__heading">Vehículos</h3>
  </div>
      <div class="section-body">
          <div class="row">
              <div class="col-lg-12">
                  <div class="card">
                      <div class="card-body">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-vehiculo')): ?>
                          <a class="btn btn-success" href="<?php echo e(route('vehiculos.create')); ?>"><i class="fas fa-plus"></i></a>
                          <?php endif; ?>

                            <table id="vehiculos" class="table table-striped table-bordered mt-2">
                              <thead>
                                  <th># Proyecto</th>
                                  <th>Vehículo</th>
                                  <th>Placas</th>
                                  <th>Acciones</th>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td><?php echo e($vehiculo->id); ?></td>
                                    <td><?php echo e($vehiculo->vehiculo); ?></td>
                                    <td><?php echo e($vehiculo->placa); ?></td>
                                    <td>
                                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-vehiculo')): ?>
                                      <a class="btn btn-warning" href="<?php echo e(route('vehiculos.edit',$vehiculo->id)); ?>"><i class="fas fa-edit"></i></a>
                                      <?php endif; ?>

                                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-vehiculo')): ?>
                                      <?php echo Form::open(['method' => 'DELETE','route' => ['vehiculos.destroy', $vehiculo->id],'style'=>'display:inline']); ?>

                                      <?php echo e(Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger'] )); ?>

                                      <?php echo Form::close(); ?>

                                      <?php endif; ?>
                                    </td>
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                          <div class="pagination justify-content-end">
                            <?php echo $vehiculos->links(); ?>

                          </div>

                      </div>
                  </div>
              </div>
          </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $("#vehiculos").DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false,
                language: {
                    "search": "Buscar:"
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\sol-automotriz\resources\views/vehiculos/index.blade.php ENDPATH**/ ?>