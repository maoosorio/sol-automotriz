@extends('layouts.app')

@section('content')
<section class="section">
  <div class="section-header">
      <h3 class="page__heading">Vehículos</h3>
  </div>
      <div class="section-body">
          <div class="row">
              <div class="col-lg-12">
                  <div class="card">
                      <div class="card-body">

                        @can('crear-vehiculo')
                          <a class="btn btn-success" href="{{ route('vehiculos.create') }}"><i class="fas fa-plus"></i></a>
                          @endcan

                            <table id="vehiculos" class="table table-striped table-bordered mt-2">
                              <thead>
                                  <th># Proyecto</th>
                                  <th>Vehículo</th>
                                  <th>Placas</th>
                                  <th>Acciones</th>
                              </thead>
                              <tbody>
                                @foreach ($vehiculos as $vehiculo)
                                  <tr>
                                    <td>{{ $vehiculo->id }}</td>
                                    <td>{{ $vehiculo->vehiculo }}</td>
                                    <td>{{ $vehiculo->placa }}</td>
                                    <td>
                                      @can('editar-vehiculo')
                                      <a class="btn btn-warning" href="{{ route('vehiculos.edit',$vehiculo->id) }}"><i class="fas fa-edit"></i></a>
                                      @endcan

                                      @can('borrar-vehiculo')
                                      {!! Form::open(['method' => 'DELETE','route' => ['vehiculos.destroy', $vehiculo->id],'style'=>'display:inline']) !!}
                                      {{ Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger'] )  }}
                                      {!! Form::close() !!}
                                      @endcan
                                    </td>
                                  </tr>
                                @endforeach
                              </tbody>
                            </table>
                          <div class="pagination justify-content-end">
                            {!! $vehiculos->links() !!}
                          </div>

                      </div>
                  </div>
              </div>
          </div>
      </div>
    </section>
@endsection

@section('js')
    <script>
        $(function() {
            $("#vehiculos").DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false,
                language: {
                    "search": "Buscar:"
                }
            });
        });
    </script>
@endsection
