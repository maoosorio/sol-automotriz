@extends('layouts.app')

@section('content')
<section class="section">
  <div class="section-header">
      <h3 class="page__heading">Usuarios</h3>
  </div>
      <div class="section-body">
          <div class="row">
              <div class="col-lg-12">
                  <div class="card">
                      <div class="card-body">

                        @can('crear-usuario')
                        <a class="btn btn-success" href="{{ route('usuarios.create') }}"><i class="fas fa-plus"></i></a>
                        @endcan

                            <table id="usuarios" class="table table-striped table-bordered mt-2">
                              <thead>
                                  <th>Nombre</th>
                                  <th>E-mail</th>
                                  <th>Rol</th>
                                  <th>Acciones</th>
                              </thead>
                              <tbody>
                                @foreach ($usuarios as $usuario)
                                  <tr>
                                    <td>{{ $usuario->name }}</td>
                                    <td>{{ $usuario->email }}</td>
                                    <td>
                                      @if(!empty($usuario->getRoleNames()))
                                        @foreach($usuario->getRoleNames() as $rolNombre)
                                          <h5><span class="badge badge-dark">{{ $rolNombre }}</span></h5>
                                        @endforeach
                                      @endif
                                    </td>

                                    <td>
                                        @can('editar-usuario')
                                        <a class="btn btn-warning" href="{{ route('usuarios.edit',$usuario->id) }}"><i class="fas fa-edit"></i></a>
                                        @endcan

                                        @can('borrar-usuario')
                                        {!! Form::open(['method' => 'DELETE','route' => ['usuarios.destroy', $usuario->id],'style'=>'display:inline']) !!}
                                        {{ Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger'] )  }}
                                        {!! Form::close() !!}
                                        @endcan
                                    </td>
                                  </tr>
                                @endforeach
                              </tbody>
                            </table>
                          <div class="pagination justify-content-end">
                            {!! $usuarios->links() !!}
                          </div>

                      </div>
                  </div>
              </div>
          </div>
      </div>
    </section>
@endsection


@section('js')
    <script>
        $(function() {
            $("#usuarios").DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false,
                language: {
                    "search": "Buscar:"
                }
            });
        });
    </script>
@endsection
